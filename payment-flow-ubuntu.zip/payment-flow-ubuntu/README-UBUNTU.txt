CARA INSTALL DI UBUNTU

1. Masuk folder project:
   cd payment-flow-ubuntu

2. Jalankan installer:
   chmod +x install-ubuntu.sh
   ./install-ubuntu.sh

3. Edit file .env:
   nano .env

4. Isi key Midtrans atau Stripe.

5. Jalankan server:
   npm start

6. Buka terminal baru, buat link Midtrans:
   npm run midtrans

7. Atau buat link Stripe:
   npm run stripe

Catatan:
- Script ini aman untuk Node.js lama, tapi installer akan upgrade ke Node.js 20.
- Untuk webhook VPS, BASE_URL harus domain/IP publik.
- Untuk lokal, gunakan ngrok/cloudflared.
