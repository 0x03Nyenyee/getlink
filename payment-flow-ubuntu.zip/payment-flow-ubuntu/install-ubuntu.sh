#!/bin/bash
set -e

echo "[1/5] Update package..."
apt update -y

echo "[2/5] Install curl..."
apt install -y curl

echo "[3/5] Install Node.js 20..."
curl -fsSL https://deb.nodesource.com/setup_20.x | bash -
apt install -y nodejs

echo "[4/5] Install dependency project..."
npm install

echo "[5/5] Membuat .env jika belum ada..."
if [ ! -f .env ]; then
  cp .env.example .env
fi

echo ""
echo "Selesai."
echo "Cek versi:"
node -v
npm -v
echo ""
echo "Edit konfigurasi:"
echo "nano .env"
echo ""
echo "Jalankan:"
echo "npm start"
echo "npm run midtrans"
echo "npm run stripe"
