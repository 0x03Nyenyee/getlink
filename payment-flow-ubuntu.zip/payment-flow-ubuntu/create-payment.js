require("dotenv").config();

var fs = require("fs");
var chalk = require("chalk");
var midtransClient = require("midtrans-client");
var Stripe = require("stripe");

var gateway = process.argv[2] || "midtrans";
var config = JSON.parse(fs.readFileSync("config.json", "utf8"));

var steps = [
  "Membaca konfigurasi pembayaran",
  "Membuat checkout " + (gateway === "stripe" ? "Stripe" : "Midtrans") + " resmi",
  "Menunggu status pembayaran",
  "Webhook menerima sukses/gagal",
  "Menampilkan link pembayaran"
];

function printStep(activeIndex) {
  console.clear();
  for (var i = 0; i < steps.length; i++) {
    var num = i + 1;
    if (i < activeIndex) {
      console.log(chalk.green("✓ " + num + ". " + steps[i]));
    } else if (i === activeIndex) {
      console.log(chalk.blue("● " + num + ". " + steps[i] + "..."));
    } else {
      console.log(chalk.gray("○ " + num + ". " + steps[i] + "..."));
    }
  }
  console.log("");
}

function sleep(ms) {
  return new Promise(function(resolve) {
    setTimeout(resolve, ms);
  });
}

async function createMidtrans() {
  printStep(0);
  await sleep(600);

  if (!process.env.MIDTRANS_SERVER_KEY || process.env.MIDTRANS_SERVER_KEY.indexOf("ISI_KEY_KAMU") !== -1) {
    throw new Error("MIDTRANS_SERVER_KEY belum diisi di file .env");
  }

  printStep(1);

  var snap = new midtransClient.Snap({
    isProduction: process.env.MIDTRANS_IS_PRODUCTION === "true",
    serverKey: process.env.MIDTRANS_SERVER_KEY,
    clientKey: process.env.MIDTRANS_CLIENT_KEY
  });

  var orderId = config.order_id + "-" + Date.now();

  var parameter = {
    transaction_details: {
      order_id: orderId,
      gross_amount: config.amount
    },
    item_details: [
      {
        id: "ITEM-001",
        price: config.amount,
        quantity: 1,
        name: config.product_name
      }
    ],
    customer_details: config.customer,
    callbacks: {
      finish: process.env.BASE_URL + "/payment/success"
    }
  };

  var transaction = await snap.createTransaction(parameter);

  printStep(2);
  await sleep(500);

  printStep(3);
  await sleep(500);

  printStep(4);
  console.log(chalk.green("Payment Link Midtrans:"));
  console.log(transaction.redirect_url);

  fs.appendFileSync(
    "payment_links.txt",
    "[MIDTRANS] " + new Date().toISOString() + " | " + orderId + " | " + transaction.redirect_url + "\n"
  );
}

async function createStripe() {
  printStep(0);
  await sleep(600);

  if (!process.env.STRIPE_SECRET_KEY || process.env.STRIPE_SECRET_KEY.indexOf("ISI_KEY_KAMU") !== -1) {
    throw new Error("STRIPE_SECRET_KEY belum diisi di file .env");
  }

  printStep(1);

  var stripe = new Stripe(process.env.STRIPE_SECRET_KEY);
  var orderId = config.order_id + "-" + Date.now();

  var session = await stripe.checkout.sessions.create({
    mode: "payment",
    payment_method_types: ["card"],
    line_items: [
      {
        price_data: {
          currency: "idr",
          product_data: {
            name: config.product_name
          },
          unit_amount: config.amount
        },
        quantity: 1
      }
    ],
    customer_email: config.customer.email,
    success_url: process.env.BASE_URL + "/payment/success?session_id={CHECKOUT_SESSION_ID}",
    cancel_url: process.env.BASE_URL + "/payment/cancel",
    metadata: {
      order_id: orderId
    }
  });

  printStep(2);
  await sleep(500);

  printStep(3);
  await sleep(500);

  printStep(4);
  console.log(chalk.green("Payment Link Stripe:"));
  console.log(session.url);

  fs.appendFileSync(
    "payment_links.txt",
    "[STRIPE] " + new Date().toISOString() + " | " + orderId + " | " + session.url + "\n"
  );
}

(async function() {
  try {
    if (gateway === "stripe") {
      await createStripe();
    } else {
      await createMidtrans();
    }

    console.log(chalk.green("\n[OK] Link disimpan ke payment_links.txt"));
    console.log(chalk.yellow("Server webhook: npm start"));
  } catch (err) {
    console.error(chalk.red("\nERROR:"), err.message);
    if (err.response && err.response.data) {
      console.error(err.response.data);
    }
    process.exit(1);
  }
})();
