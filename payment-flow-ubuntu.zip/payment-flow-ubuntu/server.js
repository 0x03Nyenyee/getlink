require("dotenv").config();

var express = require("express");
var crypto = require("crypto");
var Stripe = require("stripe");

var app = express();
var stripe = null;

if (process.env.STRIPE_SECRET_KEY && process.env.STRIPE_SECRET_KEY.indexOf("ISI_KEY_KAMU") === -1) {
  stripe = new Stripe(process.env.STRIPE_SECRET_KEY);
}

app.post("/webhook/stripe", express.raw({ type: "application/json" }), function(req, res) {
  try {
    if (!stripe) {
      return res.status(500).send("STRIPE_SECRET_KEY belum diisi");
    }

    var sig = req.headers["stripe-signature"];
    var event = stripe.webhooks.constructEvent(
      req.body,
      sig,
      process.env.STRIPE_WEBHOOK_SECRET
    );

    if (event.type === "checkout.session.completed") {
      var session = event.data.object;
      var orderId = session.metadata ? session.metadata.order_id : null;

      console.log("[STRIPE SUCCESS]", {
        session_id: session.id,
        order_id: orderId,
        amount_total: session.amount_total,
        payment_status: session.payment_status
      });
    }

    res.json({ received: true });
  } catch (err) {
    console.error("[STRIPE WEBHOOK ERROR]", err.message);
    res.status(400).send("Webhook Error: " + err.message);
  }
});

app.use(express.json());

app.get("/", function(req, res) {
  res.send("Payment server aktif");
});

app.post("/webhook/midtrans", function(req, res) {
  var body = req.body;
  var serverKey = process.env.MIDTRANS_SERVER_KEY;

  if (!serverKey || serverKey.indexOf("ISI_KEY_KAMU") !== -1) {
    return res.status(500).json({ error: "MIDTRANS_SERVER_KEY belum diisi" });
  }

  var signature = crypto
    .createHash("sha512")
    .update(body.order_id + body.status_code + body.gross_amount + serverKey)
    .digest("hex");

  if (signature !== body.signature_key) {
    return res.status(403).json({ error: "Invalid signature" });
  }

  var status = body.transaction_status;
  var fraud = body.fraud_status;

  if (status === "settlement" || (status === "capture" && fraud === "accept")) {
    console.log("[MIDTRANS SUCCESS]", body.order_id);
  } else if (status === "pending") {
    console.log("[MIDTRANS PENDING]", body.order_id);
  } else if (status === "deny" || status === "expire" || status === "cancel") {
    console.log("[MIDTRANS FAILED]", body.order_id, status);
  } else {
    console.log("[MIDTRANS STATUS]", body.order_id, status);
  }

  res.json({ ok: true });
});

app.get("/payment/success", function(req, res) {
  res.send("Pembayaran berhasil. Terima kasih.");
});

app.get("/payment/cancel", function(req, res) {
  res.send("Pembayaran dibatalkan.");
});

var port = process.env.PORT || 3000;

app.listen(port, function() {
  console.log("Server jalan di http://localhost:" + port);
  console.log("Webhook Midtrans : /webhook/midtrans");
  console.log("Webhook Stripe   : /webhook/stripe");
});
