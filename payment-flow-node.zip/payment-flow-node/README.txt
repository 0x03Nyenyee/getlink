CARA PAKAI

1. Install dependency:
   npm install

2. Copy .env.example menjadi .env
   Isi MIDTRANS_SERVER_KEY atau STRIPE_SECRET_KEY.

3. Jalankan server webhook:
   npm start

4. Buat link Midtrans:
   npm run midtrans

5. Buat link Stripe:
   npm run stripe

File output:
- payment_links.txt

Catatan:
- Untuk webhook lokal, pakai ngrok/cloudflared agar Midtrans/Stripe bisa mengirim callback.
- Midtrans webhook URL: https://domain-kamu.com/webhook/midtrans
- Stripe webhook URL: https://domain-kamu.com/webhook/stripe
