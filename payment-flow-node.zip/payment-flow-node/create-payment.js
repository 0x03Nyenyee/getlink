require("dotenv").config();
const fs = require("fs");
const axios = require("axios");
const chalk = require("chalk");
const midtransClient = require("midtrans-client");
const Stripe = require("stripe");

const gateway = process.argv[2] || "midtrans";
const config = JSON.parse(fs.readFileSync("config.json", "utf8"));

const steps = [
  "Membaca konfigurasi pembayaran",
  `Membuat checkout ${gateway === "stripe" ? "Stripe" : "Midtrans"} resmi`,
  "Menunggu status pembayaran",
  "Webhook menerima sukses/gagal",
  "Menampilkan link pembayaran",
];

function printStep(activeIndex) {
  console.clear();
  steps.forEach((s, i) => {
    const num = i + 1;
    if (i < activeIndex) console.log(chalk.green(`✓ ${num}. ${s}`));
    else if (i === activeIndex) console.log(chalk.blue(`● ${num}. ${s}...`));
    else console.log(chalk.gray(`○ ${num}. ${s}...`));
  });
  console.log("");
}

function sleep(ms) {
  return new Promise((r) => setTimeout(r, ms));
}

async function createMidtrans() {
  printStep(0);
  await sleep(600);

  printStep(1);

  const snap = new midtransClient.Snap({
    isProduction: process.env.MIDTRANS_IS_PRODUCTION === "true",
    serverKey: process.env.MIDTRANS_SERVER_KEY,
    clientKey: process.env.MIDTRANS_CLIENT_KEY,
  });

  const parameter = {
    transaction_details: {
      order_id: `${config.order_id}-${Date.now()}`,
      gross_amount: config.amount,
    },
    item_details: [
      {
        id: "ITEM-001",
        price: config.amount,
        quantity: 1,
        name: config.product_name,
      },
    ],
    customer_details: config.customer,
    callbacks: {
      finish: `${process.env.BASE_URL}/payment/success`,
    },
  };

  const transaction = await snap.createTransaction(parameter);

  printStep(2);
  await sleep(500);

  printStep(3);
  await sleep(500);

  printStep(4);
  console.log(chalk.green("Payment Link Midtrans:"));
  console.log(transaction.redirect_url);

  fs.appendFileSync(
    "payment_links.txt",
    `[MIDTRANS] ${new Date().toISOString()} | ${transaction.redirect_url}\n`
  );
}

async function createStripe() {
  printStep(0);
  await sleep(600);

  printStep(1);

  const stripe = new Stripe(process.env.STRIPE_SECRET_KEY);

  const session = await stripe.checkout.sessions.create({
    mode: "payment",
    payment_method_types: ["card"],
    line_items: [
      {
        price_data: {
          currency: "idr",
          product_data: { name: config.product_name },
          unit_amount: config.amount,
        },
        quantity: 1,
      },
    ],
    customer_email: config.customer.email,
    success_url: `${process.env.BASE_URL}/payment/success?session_id={CHECKOUT_SESSION_ID}`,
    cancel_url: `${process.env.BASE_URL}/payment/cancel`,
    metadata: {
      order_id: config.order_id,
    },
  });

  printStep(2);
  await sleep(500);

  printStep(3);
  await sleep(500);

  printStep(4);
  console.log(chalk.green("Payment Link Stripe:"));
  console.log(session.url);

  fs.appendFileSync(
    "payment_links.txt",
    `[STRIPE] ${new Date().toISOString()} | ${session.url}\n`
  );
}

(async () => {
  try {
    if (gateway === "stripe") await createStripe();
    else await createMidtrans();

    console.log(chalk.green("\n[OK] Link disimpan ke payment_links.txt"));
    console.log(chalk.yellow("\nJalankan webhook/server dengan: npm start"));
  } catch (err) {
    console.error(chalk.red("\nERROR:"), err.message);
    if (err.response?.data) console.error(err.response.data);
  }
})();
