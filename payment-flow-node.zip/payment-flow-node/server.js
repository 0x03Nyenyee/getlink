require("dotenv").config();
const express = require("express");
const crypto = require("crypto");
const Stripe = require("stripe");

const app = express();
const stripe = new Stripe(process.env.STRIPE_SECRET_KEY);

// Stripe butuh raw body khusus webhook
app.post(
  "/webhook/stripe",
  express.raw({ type: "application/json" }),
  async (req, res) => {
    try {
      const sig = req.headers["stripe-signature"];
      const event = stripe.webhooks.constructEvent(
        req.body,
        sig,
        process.env.STRIPE_WEBHOOK_SECRET
      );

      if (event.type === "checkout.session.completed") {
        const session = event.data.object;
        console.log("[STRIPE SUCCESS]", {
          session_id: session.id,
          order_id: session.metadata?.order_id,
          amount_total: session.amount_total,
          payment_status: session.payment_status,
        });
      }

      res.json({ received: true });
    } catch (err) {
      console.error("[STRIPE WEBHOOK ERROR]", err.message);
      res.status(400).send(`Webhook Error: ${err.message}`);
    }
  }
);

app.use(express.json());

app.post("/webhook/midtrans", (req, res) => {
  const body = req.body;

  const serverKey = process.env.MIDTRANS_SERVER_KEY;
  const signature = crypto
    .createHash("sha512")
    .update(body.order_id + body.status_code + body.gross_amount + serverKey)
    .digest("hex");

  if (signature !== body.signature_key) {
    return res.status(403).json({ error: "Invalid signature" });
  }

  const status = body.transaction_status;
  const fraud = body.fraud_status;

  if (status === "settlement" || (status === "capture" && fraud === "accept")) {
    console.log("[MIDTRANS SUCCESS]", body.order_id);
  } else if (status === "pending") {
    console.log("[MIDTRANS PENDING]", body.order_id);
  } else if (["deny", "expire", "cancel"].includes(status)) {
    console.log("[MIDTRANS FAILED]", body.order_id, status);
  }

  res.json({ ok: true });
});

app.get("/payment/success", (req, res) => {
  res.send("Pembayaran berhasil. Terima kasih.");
});

app.get("/payment/cancel", (req, res) => {
  res.send("Pembayaran dibatalkan.");
});

app.listen(process.env.PORT || 3000, () => {
  console.log(`Server jalan di http://localhost:${process.env.PORT || 3000}`);
  console.log("Webhook Midtrans : /webhook/midtrans");
  console.log("Webhook Stripe   : /webhook/stripe");
});
